<?php
session_start();
include_once("db2.php");



$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
?>
<?php
 ob_start();

 require_once 'db.php';
 
 // if session is not set this will redirect to login page
 if( !isset($_SESSION['user']) ) {
  header("Location: Index.php");
  exit;
 }
 // select loggedin users detail
 $res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
 $userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
	<title>Тони Пеловски </title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
	
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

	<link rel="stylesheet" href="webcss.css"  >
	
	<link rel="stylesheet" href="boots.css"  >
	<link rel="stylesheet" href="prod.css"  >
	
	<script>
		function openNav() {
			document.getElementById("mySidenav").style.width = "250px";
		}

		function closeNav() {
			document.getElementById("mySidenav").style.width = "0";
		}
	</script>
	<style>
	#search{
		margin-top:55px;
		margin-right:-200px;
	}
	#profile{
		margin-right:-185px;
	}
	</style>
				<style>
	#boton2{
	   background: #ffd633;
	   

	   -webkit-border-radius: 8;
	   -moz-border-radius: 8;
	   border-radius: 8px;
	   font-family: Arial;
	   color: black;
	   font-size: 20px;
	   padding: 10px 20px 10px 20px;
	   text-decoration: none;
	   width: 30%
	}

#boton3{
	   background: #ffd633;
	   

	   -webkit-border-radius: 8;
	   -moz-border-radius: 8;
	   border-radius: 8px;
	   font-family: Arial;
	   color: black;
	   font-size: 20px;
	   padding: 10px 20px 10px 20px;
	   text-decoration: none;
	   width: 50%
	   
	}
 	
	</style>
<title>Title</title>
<script src="js.js"></script>

</head>

<body background="http://www.bene.be/images/uploads/2012-blog/20120712/images-summer02.png"><font size="5px">
<nav background="http://www.bene.be/images/uploads/2012-blog/20120712/images-summer02.png" style="margin-bottom:0px; height:100px">
  <div class="container-fluid">
  
    <div class="navbar-header">
      <a class="navbar-brand" href="#"c>
        <img alt="" style="width:150px; height:80px;" src="img/logon.png">
      </a>
    </div>
	<form class="navbar-form navbar-right" id="search" action="search1.php" method="GET">
			<div class="form-group">
			  <input type="text" class="form-control" placeholder="Search"  type="text" name="query">
			  
			</div>
			<button type="submit" class="btn btn-default" style="font-size:15px;cursor:pointer;">Submit</button>
	</form>
  </div>
</nav>

<nav  style="height:70px; background-color:#ffff33; !Important" >
	  <div class="container-fluid" ALIGN="CENTER">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </button>
		  
		  <div id="mySidenav" class="sidenav">
			  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
			  <a href="p1.php">Начална страница</a>

			  <a href="#">Картички за рожден ден</a>
			  <a href="#">Картички за празници</a>
			  <a href="#">Картички за именни дни</a>
			   <a href="#">Покани</a>
			  <a href="#">Колажи</a>
		  </div>
		  <span style="font-size:35px;cursor:pointer" onclick="openNav()"><img src="img/threelines.png" style="height:40px; width:40px"></span>
		
		
		</div>

		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		  <ul class="nav navbar-nav">
				<li><a></a></li>
		  </ul>
	
		  <ul class="nav navbar-nav">
			<li class="dropdown">
			  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="font-size:20px;cursor:pointer">Продукти <span class="caret"></span></a>
			  <ul class="dropdown-menu">
				<li><a href="prodr.php"><font color="black">Картички</font></a></li>
				<li><a href="#"><font color="black">Колажи</font></a></li>
				<li role="separator" class="divider"></li>
				<li><a href="#"><font color="black">Направи си сам</font></a></li>
			  </ul>
			</li>
		  </ul>
		 
		  <ul class="nav navbar-nav">
				<li><a href="#">Услуги</a></li>
		  </ul>
		  <ul class="nav navbar-nav">
				<li> <a href="#">Запитване</a></li>
		  </ul>
		 
		</ul>
		
		<ul class="nav navbar-nav navbar-right" id="profile">
			<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
     <span class="glyphicon glyphicon-user"></span>&nbsp;Здравейте! <?php echo $userRow['userName']; ?><span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><font style="color:black"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</font></a></li>
              </ul>
            </li>
          </ul>
		  
		</div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>
	<h2 align="center"> Картички </h2>
	<div style="margin-left:20%; margin-top:40px; margin-bottom:20px">
<ul class="nav nav-pills" >
	<li role="presentation" style="background-color:#ffff33;"><a href="#">Картички за празници</a></li>
	<li role="presentation"><a href="#"><font color="black">Картички за рожден ден</font></a></li>
	<li role="presentation"><a href="#"><font color="black">Картички за сезони</font></a></li>
</ul>
</div>
<hr style = " background-color: #ffff33; height: 2px; ">
<div style="margin-left:10%; ">
<h1 style="margin-left:27.5%; margin-top:3%">Pr1</h1>
<canvas id="myCanvas" width="800px" height="700px" style="border:5px solid #73AD21; border-radius:5px; float:left; margin-bottom:40px; margin-right:100px; " >
   <script>
      var canvas = document.getElementById('myCanvas');
      var context = canvas.getContext('2d');
      var imageObj = new Image();

      imageObj.onload = function() {
        context.drawImage(imageObj, 0, 0);
      };
      imageObj.src = 'Holiday_Cards/1March/1March3.jpg';
    </script>
</canvas>






<div align = "center" style="float:left; border:5px solid #73AD21; border-radius:5px; width:250px; height:500px; margin-top:100px; background-color:#ffff33;">
 <button  type="button" id="boton2" style="height:40px; margin-top:20px; padding:10px 10px 10px 10px">Open</button>
 <button  type="button" id="boton2" style="height:40px; margin-top:20px; padding:10px 10px 10px 10px">Save</button>
 <br>
 <button  type="button" id="boton3" style="height:40px; width:60%; margin-top:20px; padding:10px 10px 10px 10px">Download</button>
	<div class="dropdown">
  <button id="boton3" type="button" style="height:60px; width:60%; margin-top:20px; padding:10px 10px 10px 10px" data-toggle="dropdown">Colors
  <span class="caret"></span></button>
  <ul class="dropdown-menu" style="margin-left:40px" align="center">
    <li><a href="#">Red</a></li>
    <li><a href="#">Blue</a></li>
    <li><a href="#">Yellow</a></li>
  </ul>
</div>
<div class="dropdown">
  <button id="boton3" type="button" style="height:60px; width:60%; margin-top:20px; padding:10px 10px 10px 10px" data-toggle="dropdown">Lines
  <span class="caret"></span></button>
  <ul class="dropdown-menu" style="margin-left:40px" align="center">
    <li><a href="#">1</a></li>
    <li><a href="#">2</a></li>
    <li><a href="#">3</a></li>
  </ul>
</div>
 <button  type="button" id="boton2" style="height:40px; width:60%; margin-top:20px; padding:10px 10px 10px 10px">Fill</button>
 <button  type="button" id="boton2" style="height:40px; width:60%; margin-top:20px; padding:10px 10px 10px 10px">Clear</button>
 <button  type="button" id="boton2" style="height:40px; width:60%; margin-top:20px; padding:10px 10px 10px 10px">Textbox</button>

</div>
</div>
<div id="ad">
   <iframe
      src=""
      border="0"
      scrolling="no"
      allowtransparency="true"
      width="100%"
      height="100%"
      style="border:0;">
   </iframe>
</div>
<table class="table" style="background-color:#ffff33;" style="margin-top:20px">
		<tr>
			<th COLSPAN="3"><BR><H3 ALIGN="CENTER" style="font-size:25px;cursor:pointer">Something more</H3>
			  </th>
		</tr>
		<tr ALIGN="CENTER">
			<td style="width:33%" > <a href="uslugi.html"><h3 style="font-size:20px;cursor:pointer" > Favours </h3></a> <p style="width:45%">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.  </p></td>
			<td style="width:33%"> <a href="contactform.php"><h3 style="font-size:20px;cursor:pointer"> Ask </h3></a> <p style="width:45%">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.  </p> </td>
			<td style="width:33%" > <a href=""><h3 style="font-size:20px;cursor:pointer" > Contacts</h3></a> <p >- Phone </br>- E-mail <br/>- Address</p> </td>
			
		</tr>
	
	</table>
	
	
	<nav class="navcpy">

		<p align="middle">Copyright © Copyright Животно</p>
	</nav>
	</font>
</body>



</html>