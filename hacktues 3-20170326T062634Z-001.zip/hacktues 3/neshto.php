<?php
 ob_start();

 require_once 'db.php';
 
 // if session is not set this will redirect to login page
 if( !isset($_SESSION['user']) ) {
  header("Location: Index.php");
  exit;
 }
 // select loggedin users detail
 $res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
 $userRow=mysql_fetch_array($res);

// Make sure the user actually

// selected and uploaded a file

if (isset($_FILES['image']) && $_FILES['image']['size'] > 0) {


// Temporary file name stored on the server

$tmpName = $_FILES['image']['tmp_name'];


// Read the file

$fp = fopen($tmpName, 'r');

$data = fread($fp, filesize($tmpName));

$data = addslashes($data);

fclose($fp);



// Create the query and insert

// into our database.

$query = "INSERT INTO Image ";

$query .= "(image) VALUES ('$data')";

$results = mysql_query($query, $link);


// Print results

print "Thank you, your file has been uploaded.";


}

else {

print "No image selected/uploaded";

}


// Close our MySQL Link

mysql_close($link);

?>
